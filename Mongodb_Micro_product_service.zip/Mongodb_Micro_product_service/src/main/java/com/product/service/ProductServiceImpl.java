package com.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.dao.ProductDao;
import com.product.entity.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao productDao;
	@Override
	public List<Product> getAllProducts()
	{
		return this.productDao.findAll();
	}
	@Override
	public Product getProductId(int pid) {
		// TODO Auto-generated method stub
		return this.productDao.findById(pid).get();
	}
	@Override
	public Product addProductDetail(Product p) {
		// TODO Auto-generated method stub
		return this.productDao.save(p);
	}
	@Override
	public void updateProduct(Product p, int pid) {
		// TODO Auto-generated method stub
		p.setProductId(pid);
		 this.productDao.save(p);
	}
	@Override
	public void deleteProduct(int pid) {
		// TODO Auto-generated method stub
		this.productDao.deleteById(pid);
	}
	/*@Override
	public List<Product> searchProductByPid(int personId) {
		// TODO Auto-generated method stub personId
		return this.productDao.getProductByPid(personId);
	}*/
	@Override
	public List<Product> findByPid(int pid) {
		// TODO Auto-generated method stub
		return this.productDao.findByPid(pid);
	}
		
}
