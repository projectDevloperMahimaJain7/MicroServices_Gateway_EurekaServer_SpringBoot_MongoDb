package com.user.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.user.entity.Person;
@Repository
public interface PersonDao extends MongoRepository<Person,Integer>{

}
