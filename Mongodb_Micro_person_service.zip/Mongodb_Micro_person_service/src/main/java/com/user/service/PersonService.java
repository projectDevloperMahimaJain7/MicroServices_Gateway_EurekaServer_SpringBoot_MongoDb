package com.user.service;

import java.util.List;

import com.user.entity.Person;
import com.user.entity.ProductDto;

public interface PersonService {
	public List<Person> getAllPerson();
	public Person getPersonById(int id);
	public Person addPerson(Person p);
	public Person updatePerson(Person p,int pid);
	public void deletePerson(int pid);
	public List<ProductDto> findProductByPid(int pid);
}
