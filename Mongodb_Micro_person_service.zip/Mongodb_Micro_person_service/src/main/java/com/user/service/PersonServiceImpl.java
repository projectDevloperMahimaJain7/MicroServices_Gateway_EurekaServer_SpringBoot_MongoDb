package com.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.user.dao.PersonDao;
import com.user.entity.Person;
import com.user.entity.ProductDto;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	FeignProxy proxy;
	
	@Autowired
	RestTemplate template;
	
	@Autowired
	private PersonDao personDao;
	@Override
	public List<Person> getAllPerson() {
		// TODO Auto-generated method stub
		return this.personDao.findAll();
	}
	@Override
	public Person getPersonById(int id) {
		// TODO Auto-generated method stub
		return this.personDao.findById(id).get();
	}
	@Override
	public Person addPerson(Person p) {
		// TODO Auto-generated method stub
		return this.personDao.save(p);
	}
	@Override
	public Person updatePerson(Person p, int pid) {
		// TODO Auto-generated method stub
		p.setPid(pid);
		return this.personDao.save(p);
		
	}
	@Override
	public void deletePerson(int pid) {
		// TODO Auto-generated method stub
		//this.personDao.deleteById(pid);
	}
	@Override
	public List<ProductDto> findProductByPid(int pid) {
		// TODO Auto-generated method stub
//url :http://localhost:7677/product/query/700
//String url="http://localhost:7677/product/query/"+pid;
		//String url="http://PRODUCTSERVICE/product/query/"+pid;
		//return this.template.getForObject(url, List.class);
		return proxy.findByPid(pid);
		
	}
	
	
	
	
	
}
