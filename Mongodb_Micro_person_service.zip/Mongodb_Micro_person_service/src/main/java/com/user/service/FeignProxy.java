package com.user.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//import com.product.entity.Product;
import com.user.entity.ProductDto;

//@FeignClient(name="productservice",url="http://localhost:7677/product")
@FeignClient(name="productservice")
public interface FeignProxy {

	// take below method from ProductController containing pid & change make in return type as List<ProductDto>
	//@GetMapping("/query/{pid}")
	@GetMapping("/product/query/{pid}")//after making changes using @FeignClient(name="productservice") 
	public List<ProductDto> findByPid(@PathVariable("pid")int pid);
}
