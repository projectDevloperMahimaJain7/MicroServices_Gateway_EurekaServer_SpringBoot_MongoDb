package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.entity.Person;
import com.user.entity.ProductDto;
import com.user.service.PersonService;

@RestController
@RequestMapping("/person")
public class PersonController {
	@Autowired
	private PersonService personService;
	@GetMapping("/welcome")
	public String home() {
		return "this is home page";
	}
	//http://localhost:7676/person/details
	//http://localhost:8765/person/details
	// get All Details
	@GetMapping("/details")
	public List<Person> getAllPersonDetails()
	{
		return this.personService.getAllPerson();
	}
	//get detail by id
	@GetMapping("/details/{pid}")
	public Person getDetailById(@PathVariable("pid")int pid)
	{
		return this.personService.getPersonById(pid);
	}
	//http://localhost:8765/person/details
	@PostMapping("/details")
	public Person addDetails(@RequestBody Person p)
	{
		return this.personService.addPerson(p);
		
	}
	@PutMapping("/details/{pid}")
	public Person updateDetails(@RequestBody Person p,@PathVariable("pid")int pid)
	{
	return this.personService.updatePerson(p,pid);
		
	}
	@DeleteMapping("/details/{pid}")
	public void deleteDetails(@PathVariable("pid")int pid)
	{
		this.personService.deletePerson(pid);
		
	}
	//rest template // 2nd method : feignproxy
	//http://localhost:8765/person/search/product/1
	@GetMapping("/search/product/{pid}")
	public List<ProductDto> getProductForPersonId(@PathVariable("pid")int pid)
	{
		 //rest template
		return this.personService.findProductByPid(pid);
		
		
	}
	
}
