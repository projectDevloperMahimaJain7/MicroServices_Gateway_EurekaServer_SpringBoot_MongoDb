package com.user.entity;


public class ProductDto {

	private int productId;
	private String productName;
	private String productDesc;
	private int pid;//person id
	public ProductDto(int productId, String productName, String productDesc, int pid) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDesc = productDesc;
		this.pid = pid;
	}
	public ProductDto(int productId, String productName, String productDesc) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDesc = productDesc;
	}
	public ProductDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDesc=" + productDesc
				+ ", pid=" + pid + "]";
	}
}
