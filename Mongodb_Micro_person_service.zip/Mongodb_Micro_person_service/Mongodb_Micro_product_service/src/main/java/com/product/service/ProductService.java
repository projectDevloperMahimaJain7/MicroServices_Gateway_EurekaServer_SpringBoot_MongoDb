package com.product.service;

import java.util.List;

import com.product.entity.Product;

public interface ProductService {
	public List<Product> getAllProducts();
	public Product getProductId(int pid);
	public Product addProductDetail(Product p);
	public void updateProduct(Product p,int pid);
	public void deleteProduct(int pid);
	
	/*public List<Product> searchProductByPid(int personId);*/
	public List<Product> findByPid(int pid);
	
}
